import HeroBanner from '../components/HeroBanner';
import ItemCard from '../components/ItemCard';
import { items } from "../../data/items";
import { Link } from 'react-router-dom';
import '../../css/modules/button.css';

const Home = () => {
  const featuredItems = items.slice(0, 3);

  return (
    <>
      <HeroBanner />
      <div className="d-flex justify-content-center gap-3 mt-5">
        <Link to="/items" className="btn-cta btn-cta-primary me-3">
            Ver comidas
        </Link>
        <Link to="/contacto" className="btn-cta btn-cta-secondary">
            Contacto
        </Link>
      </div>
      <main className="container my-5">
        <h2 className="text-center mb-4">Comidas Destacadas</h2>
                <div className="row row-cols-1 row-cols-md-3 g-4">
                {featuredItems.map((item) => (
                    <div className="col" key={item.id}>
                    <ItemCard
                        id={item.id}
                        image={item.image}
                        name={item.name}
                        price={item.price}
                        shortDescription={item.shortDescription}
                    />
                    </div>
                ))}
                </div>
      </main>
    </>
  );
};

export default Home;