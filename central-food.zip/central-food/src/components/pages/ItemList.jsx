import { useState, useEffect } from 'react';
import ItemCard from '../components/ItemCard';
import ItemSearch from '../components/ItemSearch';
import Skeleton from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css';
import { items as mockItems } from '../../data/items';

export default function ItemList() {
  const [items, setItems] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [loading, setLoading] = useState(true);


  useEffect(() => {
    setLoading(true);
    const timeout = setTimeout(() => {
      setItems(mockItems);
      setFiltered(mockItems);
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timeout);
  }, []);

  const handleSearch = (query) => {
    if (!query) {
      setFiltered(items);
    } else {
      setFiltered(items.filter(item => item.name.toLowerCase().includes(query.toLowerCase())));
    }
  };

  return (
    <div className="container my-5">
      <ItemSearch onSearch={handleSearch} />

      {loading ? (
        <div className="row">
          {[...Array(8)].map((_, i) => (
            <div className="col-md-3 mb-4" key={i}>
              <Skeleton height={200} />
              <Skeleton count={3} />
            </div>
          ))}
        </div>
      ) : (
        <div className="row">
          {filtered.length === 0 && <p>No se encontraron items.</p>}
          {filtered.map(item => (
            <div className="col-md-3 mb-4" key={item.id}>
              <ItemCard {...item} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}