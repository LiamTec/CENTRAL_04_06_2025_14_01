const HeroBanner = () => {
  return (
    <section
      className="hero-banner d-flex flex-column justify-content-center align-items-center text-white"
      style={{
        backgroundImage: "url('/images/centralinicio.png')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        height: "60vh",
      }}
    >

      
    </section>
  );
};

export default HeroBanner;