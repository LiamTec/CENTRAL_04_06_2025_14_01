import { useState, useEffect } from 'react';
import useDebounce from '../../hooks/useDebounce';

export default function ItemSearch({ onSearch }) {
  const [input, setInput] = useState('');
  const debouncedInput = useDebounce(input, 300);

  useEffect(() => {
    onSearch(debouncedInput.trim());
  }, [debouncedInput, onSearch]);

  return (
    <div className="mb-4">
      <input
        type="search"
        className="form-control"
        placeholder="Buscar por nombre o título..."
        value={input}
        onChange={e => setInput(e.target.value)}
        aria-label="Buscar items"
      />
    </div>
  );
}