import '../../css/modules/contactInfo.css';
export default function ContactInfo() {

  return (
    <div className="container my-5">
      <h2>Información de contacto</h2>
      <ul className="list-unstyled">
        <li><strong>Dirección:</strong> Calle Principal 123, Ciudad</li>
        <li><strong>Teléfono:</strong> +51 987 654 321</li>
        <li><strong>Email:</strong> contacto@chachirratas.com</li>
        <li><strong>Horario:</strong> Lunes a Viernes, 9am - 6pm</li>
      </ul>
    </div>
  );
}