import { useState, useEffect } from 'react';
import { notifyAdded, notifyRemoved } from '../../utils/notifyFavorite';

export default function ItemCard({ id, image, name, price, shortDescription }) {
  const [isFav, setIsFav] = useState(false);

  useEffect(() => {
    const favs = JSON.parse(localStorage.getItem('fav-items') || '[]');
    setIsFav(favs.includes(id));
  }, [id]);

  const toggleFavorite = () => {
    const favs = JSON.parse(localStorage.getItem('fav-items') || '[]');
    let updatedFavs;

    if (favs.includes(id)) {
      updatedFavs = favs.filter(favId => favId !== id);
      notifyRemoved(name);
      setIsFav(false);
    } else {
      updatedFavs = [...favs, id];
      notifyAdded(name);
      setIsFav(true);
    }

    localStorage.setItem('fav-items', JSON.stringify(updatedFavs));
  };

  return (
    <div className="card h-100 shadow-sm">
      <img src={image} className="card-img-top" alt={name} />
      <div className="card-body d-flex flex-column">
        <h5 className="card-title d-flex justify-content-between align-items-center">
          {name}
          <button
            type="button"
            onClick={toggleFavorite}
            className={`btn btn-sm ${isFav ? 'btn-warning' : 'btn-outline-secondary'}`}
            aria-label={isFav ? "Quitar favorito" : "Agregar favorito"}
            title={isFav ? "Quitar de favoritos" : "Agregar a favoritos"}
          >
            ★
          </button>
        </h5>
        <p className="card-text">{shortDescription}</p>
        <p className="fw-bold mt-auto">{price}</p>
        <button className="btn btn-primary mt-2" disabled>Ver más</button>
      </div>
    </div>
  );
}