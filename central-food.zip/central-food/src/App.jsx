import { useState } from 'react';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './css/modules/app.css';

import { BrowserRouter as Router, Routes, Route, NavLink } from 'react-router-dom';

import Home from './components/pages/Home';
import ItemList from './components/pages/ItemList';
import Contact from './components/pages/Contact';

export default function App() {
  const [searchTerm, setSearchTerm] = useState('');

  return (
    <Router>
  <div>
    <nav className="navbar navbar-expand-lg navbar-light bg-light shadow-sm py-3">
      <div className="container-fluid px-4">
        <NavLink className="navbar-brand d-flex align-items-center" to="/">
          <img src="/images/logofin.png" alt="Central" style={{ maxWidth: '200px', height: 'auto' }}/>
        </NavLink>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
              <NavLink
                to="/"
                end
                className={({ isActive }) =>
                  'nav-link' + (isActive ? ' active fw-bold text-primary' : '')
                }
              >
                Inicio
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/items"
                className={({ isActive }) =>
                  'nav-link' + (isActive ? ' active fw-bold text-primary' : '')
                }
              >
                Foods
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/contacto"
                className={({ isActive }) =>
                  'nav-link' + (isActive ? ' active fw-bold text-primary' : '')
                }
              >
                Contacto
              </NavLink>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <main className="py-5 px-4" style={{ maxWidth: '1200px', margin: '0 auto' }}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/items" element={<ItemList searchTerm={searchTerm} setSearchTerm={setSearchTerm} />} />
        <Route path="/contacto" element={<Contact />} />
      </Routes>
    </main>

    <ToastContainer position="top-right" autoClose={2000} />
  </div>
</Router>

  );
}