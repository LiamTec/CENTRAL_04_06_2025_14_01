import { toast } from 'react-toastify';

export function notifyAdded(name) {
  toast.success(`"${name}" agregado a favoritos!`);
}

export function notifyRemoved(name) {
  toast.info(`"${name}" removido de favoritos!`);
}